﻿namespace RubiksCubeModels
{
    public enum Colour
    {
        White = 0,
        Yellow,
        Red,
        Orange,
        Blue,
        Green,
    }
}
