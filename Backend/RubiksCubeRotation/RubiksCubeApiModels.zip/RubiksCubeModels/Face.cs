﻿namespace RubiksCubeModels
{
    public enum Face
    {
        Up,
        Down,
        Front,
        Back,
        Right,
        Left,
    }
}
